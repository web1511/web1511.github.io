import React, { Component } from 'react'

class Login extends Component {
 render(){
   return (
     <div>
         <h2>这是登录页面啦啦啦</h2>
     </div>
   )
 }
}

export default Login